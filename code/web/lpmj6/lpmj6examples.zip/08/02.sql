this is "meaningless gibberish to mysql" \c
