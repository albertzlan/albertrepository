DELETE FROM classics WHERE title='Little Dorrit';
