<?php
  list($a, $b) = array('Alice', 'Bob');
  echo "a=$a b=$b";
?>
